import { initAll } from 'govuk-frontend';

import '../scss/main.scss';
import './go-back';
import './cookie';
initAll();
