export const contact_en = `<b>Web Chat</b> </br> </br>
                           No agents are available, please try again later. </br> </br> 
                           <u>Email</u> </br> 
                           <u>contact@justice.gov.uk</u> </br></br>
                           We aim to get back to you within 5 days.</br></br>
                           <b>Telephone</b></br></br>
                           0300 303 0742</br>
                           Monday to Friday, 8am to 8pm, Saturday, 8am to 2pm`;

export const contact_cy = `<b>Web Chat</b> </br> </br>
                           No agents are available, please try again later. </br> </br> 
                           <u>Email</u> </br> 
                           <u>contact@justice.gov.uk</u> </br></br>
                           We aim to get back to you within 5 days.</br></br>
                           <b>Telephone</b></br></br>
                           0300 303 0742</br>
                           Monday to Friday, 8am to 8pm, Saturday, 8am to 2pm`;
