export const defaultButtons = {
  submit: {
    text: (l: Record<string, never>): string => l.continue,
  },
  saveAsDraft: {
    text: (l: Record<string, never>): string => l.saveAsDraft,
  },
};
