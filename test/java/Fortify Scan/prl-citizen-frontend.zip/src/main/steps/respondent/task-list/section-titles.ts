export const respondent_en = {
  respondentYourDetails: 'Your details',
  applicationDetails: 'Application details',
  consentToTheApplication: 'Consent to the application',
  respondentAdditionalInformation: 'Additional information',
  respondentSafetyConcerns: 'Safety concerns',
};
