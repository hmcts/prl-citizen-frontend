export const respondent_tasklist_items_en = {
  keep_your_details_private: 'Keep your details private',
  do_you_consent_to_the_application: 'Do you consent to the application?',
  confirm_or_edit_your_contact_details: 'Confirm or edit your contact details',
  mediation_miam: 'Mediation(MIAM)',
  international_factors: 'International element',
  current_or_previous_proceedings: 'Current or previous proceedings',
  your_safety: 'Your safety',
};
