declare module 'govuk-frontend' {
  export function initAll(): void;
}
